function [n_0,phi_0,R_clot_0,epsilon_0] = clotProperty_func(N_AV,R_f0,rho_0,rho_fibre,dr,dth,L_M,RG,H)

% Total number of layers per cross-section
N_layer = R_f0/dr;

% Calculating the number of binding sites per cross-section
it = 1:N_layer;
BS_CS = sum(pi./asin(dth./(2*it*dr)));

Mw = 340;   % kDa = kg/mole

% Fibre length density
LtVt = (rho_0/(rho_fibre*1000))*1E21/(pi*R_f0*R_f0) ;

% Density of cross-sections
CS_V = 2*LtVt/(1E12)*L_M;


%% Return
% Calculate clot properties
    % Alpha value, source from Diamond's review paper, "Engineering...."
    if R_f0>=300 % [nm]
        alp = 0.0171;
    elseif R_f0<=100 % [nm]
        alp = 0.0143;
    else
        alp = 0.5*(0.0143+0.0171);
    end
% Calculate clot properties
 C = ( (RG) - (H+(1-H)*alp))/((1-H)*(1-alp));
    epsilon_0 = (C*(1-alp))/(alp+C*(1-alp))
phi_0 = 1-epsilon_0;    
n_0 = 2*CS_V * BS_CS*1E6*1E15*(1-epsilon_0)/N_AV;
permb = permeability_func(R_f0,phi_0);
% permb = (1e-18*R_f0*R_f0*4)/(70*(phi_0^1.5)*( 1+52*phi_0^1.5 ));
R_clot_0 = 1/permb;  % in [1/m2]

