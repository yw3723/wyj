%% GSA_Init: initialize the variables used in the GSA computation
%
% Usage:
%   pro = GSA_Init(pro)
%
% Inputs:
%    pro                project structure
%
% Output:
%    pro                project structure
%
% ------------------------------------------------------------------------
% Citation: Cannavo' F., Sensitivity analysis for volcanic source modeling quality assessment and model selection, Computers & Geosciences, Vol. 44, July 2012, Pages 52-59, ISSN 0098-3004, http://dx.doi.org/10.1016/j.cageo.2012.03.008.
% See also
%
% Author : Flavio Cannavo'
% e-mail: flavio(dot)cannavo(at)gmail(dot)com
% Release: 1.0
% Date   : 15-02-2011
%
% History:
% 1.0  15-01-2011  First release.
%      06-01-2014  Added comments.
%%
function pro = GSA_Init(pro)
global j
% get two sets of samples of the input variables
[E, T] = fnc_SampleInputs(pro);

pro.SampleSets.E = E;
pro.SampleSets.T = T;

% get the number of input variables
n = length(pro.Inputs.pdfs);

% set the number of possible combinations of the input variables
L = 2^n;
N = pro.N;

% prepare the structure for the evaluation of the model at the sample
% points in the set E
fE_GSA = nan(N, 1);

% prepare to store input-output pairs (using a cell array)
input_output_pairs = cell(N, 1);

% evaluate the model at the sample points in the set E
parfor j = 1:N
    % Get the current sample input
    current_input = pro.SampleSets.E(j, :);
    
    % Evaluate the model, assuming the model function returns finishTimeInd
    g = pro.Model.handle(current_input);
    
    % Store the input values and the corresponding output value (finishTimeInd)
    input_output_pairs{j} = [current_input, g];
    
    % Also store the output in fE_GSA for consistency
    fE_GSA(j) = g;
end

% Convert the cell array to a matrix after the parfor loop
input_output_pairs_matrix = cell2mat(input_output_pairs);

% Assign back 
pro.GSA.fE = fE_GSA;

% Store input-output pairs as a matrix
pro.GSA.input_output_pairs = input_output_pairs_matrix;

% Store input-output pairs as a matrix
pro.GSA.input_output_pairs = input_output_pairs_matrix;

% Store input-output pairs
pro.GSA.input_output_pairs = input_output_pairs;

% calculate the mean value of the model outcomes
pro.GSA.mfE = nanmean(pro.GSA.fE);

if isnan(pro.GSA.mfE)
    pro.GSA.mfE = 0;
end

% subtract the mean values from the model outcomes 
pro.GSA.fE = pro.GSA.fE - pro.GSA.mfE;

% calculate the mean values (it will be 0)
pro.GSA.f0 = nanmean(pro.GSA.fE);

% calculate the total variance of the model outcomes
pro.GSA.D  = nanmean(pro.GSA.fE.^2) - pro.GSA.f0^2;

% approximate the error of the mean value
pro.GSA.ef0 = 0.9945*sqrt(pro.GSA.D/sum(~isnan(pro.GSA.fE)));

% prepare the structures for the temporary calculations of sensitivity
% coefficients
pro.GSA.Dmi = nan(1,L-1);
pro.GSA.eDmi = nan(1,L-1);

pro.GSA.Di = nan(1,L-1);
pro.GSA.eDi = nan(1,L-1);

pro.GSA.GSI = nan(1,L-1);
pro.GSA.eGSI = nan(1,L-1);