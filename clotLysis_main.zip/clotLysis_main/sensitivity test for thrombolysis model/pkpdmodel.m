
%% ---------------------------------------------------------------------- %
% Two Compartmental model                                                 %
% programmed by B Gu, 18/08/2018, modified 20/12/2018                     %
% ----------------------------------------------------------------------- %
function g=pkpdmodel(x)
clc;% clear all; format long; close all;
global kel_PLG kel_PLS kel_FBG kel_AP kel_MG kel_PAI k12 k21 k10
%global kcat_tPA KM_tPA kcat_PLS KM_PLS kMG kPAI kcat_AP KM_AP
global C_tPA0 C_PLG0 C_PLS0 C_FBG0 C_AP0 C_MG0 C_PAI0 
global k1f k1r k2 k3f k3r k4 k5f k5r k6 kMG kPAI
global KM_PLG k_PLG_cat k_AP_f k_AP_r k_AP_cat KM_FBG k_FBG_cat kMG kPAI
%%format long; close all;
global density viscosity Dcoeff Q_ICA D_ICA D_ACA D_MCA
global R_f0 epsilon_0 n_0 phi_0 R_clot_0 dpdx_clot EL_crit
global dt dx nt nx couplingON
global ka_tPA kd_tPA ka_PLG kd_PLG ka_PLS kd_PLS k_MM KM k_deg gamma
%global KM_PLG k_PLG_cat k_AP_f k_AP_r k_AP_cat KM_FBG k_FBG_cat kMG kPAI
global finishTimeInd plasmaReactOn N_free N_bound
tic;
%% Properties Parameters
[k12,k21,k10,kel_PLG,kel_PLS,kel_FBG,kel_AP,kel_MG,kel_PAI] = elimination_para();

%% Kinetic parameters
% [kcat_tPA,KM_tPA,kcat_PLS,KM_PLS,kcat_AP,KM_AP,kMG,kPAI] = kinetic_para();
% [,k2,k3f,k3r,k4,k5f,k5r,k6,kMG,kPAI] = kinetic_para();
%[KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
% [x(1),x(2),k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();

%[x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9),x(10),x(11)]=kinetic_para();
% Properties Parameters
%[k12,k21,k10,kel_PLG,kel_PLS,kel_FBG,kel_AP,kel_MG,kel_PAI] = elimination_para();
k12=x(19);
k21=x(20);
k10=x(21);
kel_PLG=x(22);
kel_PLS=x(23);
kel_FBG=x(24);
kel_AP=x(25);
kel_MG =x(26);
kel_PAI=x(27);
%% Kinetic parameters
% [kcat_tPA,KM_tPA,kcat_PLS,KM_PLS,kcat_AP,KM_AP,kMG,kPAI] = kinetic_para();
% [k1f,k1r,k2,k3f,k3r,k4,k5f,k5r,k6,kMG,kPAI] = kinetic_para();
%[KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
%[x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9)] = kinetic_para();
%[x(1),x(2),k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
KM_PLG=x(1);
k_PLG_cat=x(2);
k_AP_f=x(3);
k_AP_r=x(4);
k_AP_cat=x(5);
KM_FBG=x(6);
k_FBG_cat=x(7);
kMG=x(8);
kPAI=x(9);

%% initial concentrations in plasma
[C_tPA0,C_PLG0,C_PLS0,C_FBG0,C_AP0,C_MG0,C_PAI0] = initConc_values();
%% Treatment specific parameters
% === INPUT ===============================================================
tPAdose = 0.9*80;                     % total tPA dose in [mg]
N_stage = 2;
t_infusion = [1,60]*60;    % infusion duration [s]
t_delay = [0]*60;           % time delay between infusion modes [s]
perc_infusion = [0.1,0.9];    % percentage of each infusion of total amount [-]
% =========================================================================
[tPAdose_array, timePoints, t_ramping] = dosageRegimen_func(tPAdose,N_stage,t_infusion,t_delay,perc_infusion);
%% Calculate infusion rate
dt = 0.01;%0.075;
% tspan = 0:dt:(sum(timePoints)+60*100);       % simulation duration [s]
% tspan = 0:dt:3600+60+30*60;       % simulation duration [s]
tspan = 0:dt:300*60
for ii=1:length(tspan)
    IR_tPA(ii) = infusionRate_func_general(tspan(ii), tPAdose_array, timePoints, t_ramping);
end

% dd
%% Solve ODE for the compartmental model
% --- initial conc. [central tPA, pheripheral tPA, PLG, PLS, FBG, AP, MG, PAI] [micro M] - 9 factors
Cintit = [C_tPA0, 0, C_PLG0, C_PLS0, C_FBG0, C_AP0, C_MG0, C_PAI0, 0];
[tsolve,Csolve] = ode23s(@compartmentalODE_NewFunc,tspan,Cintit,[],tPAdose_array,timePoints,t_ramping);
%%
%% Fluid and protiens parameters
density = 1060;             % density of fluid [kg/m3]
kinVis = 3.5e-6;            % kinematic viscosity [m2/s]
viscosity = kinVis*density;              % dynamic viscosity [Pa s]
Dcoeff = 5e-11;             % dispersion coeff of proteins [m2/s]
Q_ICA = 4.31e-6;            % flowrate at ICA [m3/s]

%% Arterial geometry
D_ICA = 3.35e-3;            % diameter of ICA [m]
D_ACA = 2.20e-3;            % diameter of ACA [m]
D_MCA = 3.00e-3;            % diameter of MCA [m]
L_MCA = 15e-3;              % length of MCA [m]
%% Information on clot
L_clot = 5e-3;  % length of clot [m]
%L_clot = x(3)
clotPos = 5e-3;%0.1*propPara.L_MCA;        % clot position, distance from the MCA start [m]
dpdx_clot_mmHg_cm = 60;                    % in mmHg/cm
dpdx_clot = dpdx_clot_mmHg_cm*133.32*1e2;  % in Pa/m
%dpdx_clot =x(4);
% *************************
%epsilon_0=x(1);
%R_f0=x(2);
R_f0 = 100;             % fibre radius [nm]
epsilon_0 = 0.95;  
% initial voidage
%epsilon_0=x(10)
N_AV = 6.02E23;        % avogaro's number
rho_0 = 3;
rho_fibre = 0.28;       % 0.28 0.21
dr = 10;
dth = 10;
L_M = 0.04444;
% *************************
[n_0,phi_0,R_clot_0] = clotProperty_func(N_AV,R_f0,rho_0,rho_fibre,dr,dth,L_M,epsilon_0);

%% Kinetic parameters for fibrinolysis
%[ka_tPA,kd_tPA,ka_PLG,kd_PLG,ka_PLS,kd_PLS,k_MM,KM,k_deg,gamma] = fibrinolytic_para();
%[KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
%[x(10),x(11),x(12),x(13),x(14),x(15),x(16),x(17),x(18),gamma] = fibrinolytic_para();
%[KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
ka_tPA=x(10);
kd_tPA=x(11);
ka_PLG=x(12);
kd_PLG=x(13);
ka_PLS=x(14);
kd_PLS=x(15);
k_MM =x(16);
KM=x(17);
k_deg=x(18);
gamma=10;
EL_crit = 0.8;
plasmaReactOn = 0; % 1: plasma reactions to be inluded
%% Discretisation for FDM
% -------------------------------------------------------------------------
dx = 0.1e-3;           % discreised segment size [m]
% -------------------------------------------------------------------------
if clotPos>0
    if dx>L_clot || dx>clotPos
        warning('Selected dxx > Length of clot or distance between clot front and birfucation!!');
        fprintf('The value of dxx is changed to "clotPos" %2.2e...\n',clotPos); pause
        fprintf('Wish to continue with the new dxx value? If yes, hit any key, otherwise, ctrl+C.\n');
    end
end
n_MCA1 = round(clotPos/dx);    % No. of discretised segments in MCA region 1 (clot free region proximal to bifurcation)
n_MCA2 = round(L_clot/dx);     % No. of discretised segments in MCA region 2 (clot)
nx = [n_MCA1, n_MCA2];

%% Temporal discretisation: even distribution
% -------------------------------------------------------------------------
dt = 0.075;
% -------------------------------------------------------------------------
tf = 60*300;
nt = tf/dt;

%% Variables to be solved
couplingON = 1;
N_free = 8;     % Number of free phase species
N_bound = 5;    % Number of bound phase species
% --- free phase concentration
% Initial concentrations
C_tPA_t0 = 0.00005;     % free tPA conc. [microM]
C_PLG_t0 = 2.2;         % free PLG conc. [microM] 
C_PLS_t0 = 0;           % free PLS conc. [microM] 
C_FBG_t0 = 8;           % fibrinogen conc. [microM]
C_AP_t0 = 1;            % free AP conc. [microM]
C_MG_t0 = 3;            % free MG conc. [microM]
C_PAI_t0 = 22.5/(43e3); % free PAI conc. [microM]
C_PLS_AP_t0 = 0;        % free PLS-AP complex conc. [microM]
% Inlet concentrations
C_tPA_x0 = 25e-3;       % Inlet free tPA conc. [microM]
C_PLG_x0 = 2.2;         % Inlet free PLG conc. [microM] 
C_PLS_x0 = 0;           % Inlet free PLS conc. [microM]
C_FBG_x0 = 8;           % Inlet fibrinogen conc. [microM]
C_AP_x0 = 1;            % Inlet free AP conc. [microM]
C_MG_x0 = 3;            % Inlet MG conc. [microM]
C_PAI_x0 = 22.5/(43e3); % Inlet PAI conc. [microM]
C_PLS_AP_x0 = 0;        % Inlet PLS-AP complex conc. [microM]

% vectors
initCond = [C_tPA_t0,C_PLG_t0,C_PLS_t0,C_FBG_t0,C_AP_t0,C_MG_t0,...
    C_PAI_t0,C_PLS_AP_t0]; % 1x8
inletCond = [C_tPA_x0,C_PLG_x0,C_PLS_x0,C_FBG_x0,C_AP_x0,C_MG_x0,...
    C_PAI_x0,C_PLS_AP_x0]; % 1x8

if couplingON
    % dirName = 'C:\Users\yy1319\Desktop\clotLysis2\TwoCompartCoupledLysisModel - copy\';
    %variableName = 'refRegimen.mat';
    %fullName = [dirName,variableName];
    %load(fullName);
    inletCond = Csolve(2:end,[1,3:end]); % no.of time seg x 8
end

ret = solveArteries_func(initCond,inletCond); toc;
if isempty(finishTimeInd)
    fprintf('Clot NOT completely dissolved within Time = %5.2f [min]...\n',tf/60);
else
    fprintf('Clot completly dissolved at Time = %5.2f [min]...\n',(finishTimeInd-1)*dt/60);
    fprintf('Finish time index = %d ...\n',finishTimeInd);
end

g=finishTimeInd;
end


