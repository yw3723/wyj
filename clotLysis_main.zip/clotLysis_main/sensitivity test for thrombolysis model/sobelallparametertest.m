clear
clc
tic
% create a new project 
pro = pro_Create();
%pk model parameter
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param1');
pro = pro_AddInput(pro, @()pdf_Sobol([1 300]), 'param2');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param3');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param4');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param5');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param6');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param7');
pro = pro_AddInput(pro, @()pdf_Sobol([1 300]), 'param8');
pro = pro_AddInput(pro, @()pdf_Sobol([25 250]), 'param9');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param10');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param11');
%pd model parameter
pro = pro_AddInput(pro, @()pdf_Sobol([0.01 0.1]), 'param12');
pro = pro_AddInput(pro, @()pdf_Sobol([0.001 0.01]), 'param13');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param14');
pro = pro_AddInput(pro, @()pdf_Sobol([1 10]), 'param15');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param16');
pro = pro_AddInput(pro, @()pdf_Sobol([0.01 0.1]), 'param17');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param18');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param19');
pro = pro_AddInput(pro, @()pdf_Sobol([1 3]), 'param20');


pro = pro_SetModel(pro, @(x)compartmentalModel_NewMain1(x), 'model');

pro.N = 10;

pro = GSA_Init(pro);

Sfast = GSA_FAST_GetSi(pro);
[S1, eS1, pro] = GSA_GetSy(pro, {1});
[S2, eS2, pro] = GSA_GetSy(pro, {2});
[S3, eS3, pro] = GSA_GetSy(pro, {3});
[S4, eS4, pro] = GSA_GetSy(pro, {4});
[S5, eS5, pro] = GSA_GetSy(pro, {5});
[S6, eS6, pro] = GSA_GetSy(pro, {6});
[S7, eS7, pro] = GSA_GetSy(pro, {7});
[S8, eS8, pro] = GSA_GetSy(pro, {8});
[S9, eS9, pro] = GSA_GetSy(pro, {9});
[S10,es10,pro] = GSA_GetSy(pro, {10});
[S11,es11,pro] = GSA_GetSy(pro, {11});

[S12, eS12, pro] = GSA_GetSy(pro, {12});
[S13, eS13, pro] = GSA_GetSy(pro, {13});
[S14, eS14, pro] = GSA_GetSy(pro, {14});
[S15, eS15, pro] = GSA_GetSy(pro, {15});
[S16, eS16, pro] = GSA_GetSy(pro, {16});
[S17, eS17, pro] = GSA_GetSy(pro, {17});
[S18, eS18, pro] = GSA_GetSy(pro, {18});
[S19, eS19, pro] = GSA_GetSy(pro, {19});
[S20, eS20, pro] = GSA_GetSy(pro, {20});

[Stot1, eStot1, pro] = GSA_GetTotalSy(pro, {'param1'});
[Stot2, eStot2, pro] = GSA_GetTotalSy(pro, {'param2'});
[Stot3, eStot3, pro] = GSA_GetTotalSy(pro, {'param3'});
[Stot4, eStot4, pro] = GSA_GetTotalSy(pro, {'param4'});
[Stot5, eStot5, pro] = GSA_GetTotalSy(pro, {'param5'});
[Stot6, eStot6, pro] = GSA_GetTotalSy(pro, {'param6'});
[Stot7, eStot7, pro] = GSA_GetTotalSy(pro, {'param7'});
[Stot8, eStot8, pro] = GSA_GetTotalSy(pro, {'param8'});
[Stot9, eStot9, pro] = GSA_GetTotalSy(pro, {'param9'});
[Stot10, eStot10, pro] = GSA_GetTotalSy(pro, {'param10'});
[Stot11, eStot11, pro] = GSA_GetTotalSy(pro, {'param11'});
[Stot12, eStot12, pro] = GSA_GetTotalSy(pro, {'param12'});
[Stot13, eStot13, pro] = GSA_GetTotalSy(pro, {'param13'});
[Stot14, eStot14, pro] = GSA_GetTotalSy(pro, {'param14'});
[Stot15, eStot15, pro] = GSA_GetTotalSy(pro, {'param15'});
[Stot16, eStot16, pro] = GSA_GetTotalSy(pro, {'param16'});
[Stot17, eStot17, pro] = GSA_GetTotalSy(pro, {'param17'});
[Stot18, eStot18, pro] = GSA_GetTotalSy(pro, {'param18'});
[Stot19, eStot19, pro] = GSA_GetTotalSy(pro, {'param19'});
[Stot20, eStot20, pro] = GSA_GetTotalSy(pro, {'param20'});


toc
