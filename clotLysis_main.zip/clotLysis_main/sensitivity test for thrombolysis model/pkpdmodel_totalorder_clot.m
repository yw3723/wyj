% create a new project 

pro = pro_Create();
%pk model parameter % Sobol quasi-random set 
pro = pro_AddInput(pro, @()pdf_Sobol([0.935 1]), 'param1'); %Porosity
pro = pro_AddInput(pro, @()pdf_Sobol([40 180]), 'param2'); %Fiber Diameter
pro = pro_AddInput(pro, @()pdf_Sobol([0.002 0.008]), 'param3'); %Clot Length
pro = pro_AddInput(pro, @()pdf_Sobol([2e+5 8e+5]), 'param4');%Pressure Drop
pro = pro_AddInput(pro, @()pdf_Sobol([0 0.01]), 'param5'); %Clot Position


a=length(pro.Inputs.pdfs);
pro = pro_SetModel(pro, @(x)pkpdmodel_clot(x), 'model');

% set the number of samples for the quasi-random Monte Carlo simulation
pro.N = 150;

% initialize the project by calculating the model at the sample points
pro = GSA_Init(pro);


% Preallocate results for parallel execution
numParams = 5;  % Assuming you have 27 parameters
Stot = cell(1, numParams);
eStot = cell(1, numParams);

% Run the sensitivity analysis in parallel
parfor i = 1:numParams
    % Local copy of 'pro' to avoid modifying the original in parallel
    local_pro = pro;
    [Stot{i}, eStot{i}] = GSA_GetTotalSy(local_pro, {i});
end

% Now, S and eS contain the results for all parameters