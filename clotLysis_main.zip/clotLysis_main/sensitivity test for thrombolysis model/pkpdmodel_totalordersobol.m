% create a new project 

pro = pro_Create();
%pk model parameter % Sobol quasi-random set 
pro = pro_AddInput(pro, @()pdf_Sobol([14.02 42.05]), 'param1'); %KM_PLG
pro = pro_AddInput(pro, @()pdf_Sobol([0.15 0.45]), 'param2'); %k_PLG_cat
pro = pro_AddInput(pro, @()pdf_Sobol([5 15]), 'param3'); %k_AP_f
pro = pro_AddInput(pro, @()pdf_Sobol([0.00105 0.00315]), 'param4');%k_AP_r
pro = pro_AddInput(pro, @()pdf_Sobol([0.002 0.006]), 'param5');%k_AP_cat
pro = pro_AddInput(pro, @()pdf_Sobol([27.5 82.5]), 'param6'); %KM_FBG
pro = pro_AddInput(pro, @()pdf_Sobol([125 375]), 'param7'); %k_FBG_cat
pro = pro_AddInput(pro, @()pdf_Sobol([0.175 0.525]), 'param8'); %kMG
pro = pro_AddInput(pro, @()pdf_Sobol([18.5 55.5]), 'param9'); %kPAI
pro = pro_AddInput(pro, @()pdf_Sobol([0.005 0.015]), 'param10');%ka_tPA
pro = pro_AddInput(pro, @()pdf_Sobol([0.0029 0.0087]), 'param11');%kd_tPA
pro = pro_AddInput(pro, @()pdf_Sobol([0.05 0.15]), 'param12'); %ka_PLG
pro = pro_AddInput(pro, @()pdf_Sobol([1.9 5.7]), 'param13'); %kd_PLG
pro = pro_AddInput(pro, @()pdf_Sobol([0.05 0.15]), 'param14'); %ka_PLS
pro = pro_AddInput(pro, @()pdf_Sobol([0.025 0.075]), 'param15');%kd_PLS
pro = pro_AddInput(pro, @()pdf_Sobol([0.15 0.45]), 'param16'); %k_MM
pro = pro_AddInput(pro, @()pdf_Sobol([0.095 0.285]), 'param17');%KM
pro = pro_AddInput(pro, @()pdf_Sobol([1.089 3.267]), 'param18'); %k_deg
pro = pro_AddInput(pro, @()pdf_Sobol([0.000155 0.000466]), 'param19'); %k12
pro = pro_AddInput(pro, @()pdf_Sobol([0.000167 0.000501]), 'param20'); %k21
pro = pro_AddInput(pro, @()pdf_Sobol([0.00115 0.00345]), 'param21'); %k10
pro = pro_AddInput(pro, @()pdf_Sobol([0.00000182 0.00000547]), 'param22'); %kel_PLG
pro = pro_AddInput(pro, @()pdf_Sobol([3.47 10.40]), 'param23'); %kel_PLS
pro = pro_AddInput(pro, @()pdf_Sobol([0.00000097 0.00000291]), 'param24'); %kel_FBG
pro = pro_AddInput(pro, @()pdf_Sobol([0.00000152 0.00000456]), 'param25'); %kel_AP
pro = pro_AddInput(pro, @()pdf_Sobol([0.00195 0.00585]), 'param26'); %kel_MG
pro = pro_AddInput(pro, @()pdf_Sobol([0.0000642 0.0001925]), 'param27'); %kel_PAI



a=length(pro.Inputs.pdfs);
pro = pro_SetModel(pro, @(x)pkpdmodel(x), 'model');

% set the number of samples for the quasi-random Monte Carlo simulation
pro.N = 2000;

% initialize the project by calculating the model at the sample points
pro = GSA_Init(pro);


% Preallocate results for parallel execution
numParams = 27;  % Assuming you have 27 parameters
Stot = cell(1, numParams);
eStot = cell(1, numParams);

% Run the sensitivity analysis in parallel
parfor i = 1:numParams
    % Local copy of 'pro' to avoid modifying the original in parallel
    local_pro = pro;
    [Stot{i}, eStot{i}] = GSA_GetTotalSy(local_pro, {i});
end

% Now, S and eS contain the results for all parameters