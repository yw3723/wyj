clc;clear all;
% create a new project 
global N
pro = pro_Create();
%pk model parameter
pro = pro_AddInput(pro, @()pdf_Sobol([1 150]), 'param1');
%pro = pro_AddInput(pro, @()pdf_Sobol([1 300]), 'param2');
pro = pro_AddInput(pro, @()pdf_Sobol([0.001 1]), 'param2');

pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param3');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param4');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param5');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param6');
pro = pro_AddInput(pro, @()pdf_Sobol([100 300]), 'param7');
%pro = pro_AddInput(pro, @()pdf_Sobol([25 250]), 'param9');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param8');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param9');
%pd model parameter
pro = pro_AddInput(pro, @()pdf_Sobol([0.01 0.1]), 'param10');
pro = pro_AddInput(pro, @()pdf_Sobol([0.001 0.01]), 'param11');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param12');
pro = pro_AddInput(pro, @()pdf_Sobol([1 10]), 'param13');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param14');
pro = pro_AddInput(pro, @()pdf_Sobol([0.01 0.1]), 'param15');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param16');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param17');
pro = pro_AddInput(pro, @()pdf_Sobol([2.1 2.2]), 'param18');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-4 1e-3]), 'param19');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-4 1e-3]), 'param20');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-4 3e-3]), 'param21');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-6 1e-5]), 'param22');
pro = pro_AddInput(pro, @()pdf_Sobol([0.01 7]), 'param23');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-6 1e-5]), 'param24');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-6 1e-5]), 'param25');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param26');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-4 1e-3]), 'param27');
%a=length(pro.Inputs.pdfs);
pro = pro_SetModel(pro, @(x)pkpdmodel(x), 'model');

%pro.N = 1;

%fprintf('result is %3.2e\n',A);
%pro = GSA_Init(pro);
%
%[Set1 Set2] = fnc_SampleInputs(pro);
Sfast = GSA_FAST_GetSi(pro)
a=Sfast