clc; clear
% create a new project 
pro = pro_Create();
%pk model parameter
pro = pro_AddInput(pro, @()pdf_Sobol([10 1000]), 'param1');
%pro = pro_AddInput(pro, @()pdf_Sobol([1 300]), 'param2');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param2');

pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param3');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param4');
pro = pro_AddInput(pro, @()pdf_Sobol([1e-3 1e-2]), 'param5');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param6');
pro = pro_AddInput(pro, @()pdf_Sobol([1 300]), 'param7');
%pro = pro_AddInput(pro, @()pdf_Sobol([25 250]), 'param9');
pro = pro_AddInput(pro, @()pdf_Sobol([0.1 1]), 'param8');
pro = pro_AddInput(pro, @()pdf_Sobol([10 100]), 'param9');
%pd model parameter


pro = pro_SetModel(pro, @(x)COMPARTMENTMODELSENSITIVITY(x), 'model');

pro.N = 100;

pro = GSA_Init(pro);
%
%[Set1 Set2] = fnc_SampleInputs(pro);
Sfast = GSA_FAST_GetSi(pro);