% Ishigami test function (section 3.0.1)
function g = TestModel2(x)

g = sin(x(1))+5*(sin(x(2))^2) + 0.1*(x(3)^4)*sin(x(1));
