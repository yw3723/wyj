% Two Compartmental model                                                 %
% programmed by B Gu, 18/08/2018, modified 20/12/2018                     %
% ----------------------------------------------------------------------- %
function g=COMPARTMENTMODELSENSITIVITY(x)
clc;% clear all; format long; close all;
global kel_PLG kel_PLS kel_FBG kel_AP kel_MG kel_PAI k12 k21 k10
%global kcat_tPA KM_tPA kcat_PLS KM_PLS kMG kPAI kcat_AP KM_AP
global C_tPA0 C_PLG0 C_PLS0 C_FBG0 C_AP0 C_MG0 C_PAI0 
global k1f k1r k2 k3f k3r k4 k5f k5r k6 kMG kPAI
global KM_PLG k_PLG_cat k_AP_f k_AP_r k_AP_cat KM_FBG k_FBG_cat kMG kPAI
%%format long; close all;
global density viscosity Dcoeff Q_ICA D_ICA D_ACA D_MCA
global R_f0 epsilon_0 n_0 phi_0 R_clot_0 dpdx_clot EL_crit
global dt dx nt nx couplingON
global ka_tPA kd_tPA ka_PLG kd_PLG ka_PLS kd_PLS k_MM KM k_deg gamma
%global KM_PLG k_PLG_cat k_AP_f k_AP_r k_AP_cat KM_FBG k_FBG_cat kMG kPAI
global finishTimeInd plasmaReactOn N_free N_bound
tic;
%% Properties Parameters
[k12,k21,k10,kel_PLG,kel_PLS,kel_FBG,kel_AP,kel_MG,kel_PAI] = elimination_para();

%% Kinetic parameters
% [kcat_tPA,KM_tPA,kcat_PLS,KM_PLS,kcat_AP,KM_AP,kMG,kPAI] = kinetic_para();
% [,k2,k3f,k3r,k4,k5f,k5r,k6,kMG,kPAI] = kinetic_para();
%[KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
% [x(1),x(2),k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();

%[x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9),x(10),x(11)]=kinetic_para();
 %[x(1),x(2),KM_PLG,x(3),k_AP_f,k_AP_r,k_AP_cat,k5f,k5r,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
 %[k1f,k1r,KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,k5f,k5r,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
%[k1f,k1r,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,k5f,k5r,k_FBG_cat,kMG,kPAI] = kinetic_para();
% Properties Parameters
[k12,k21,k10,kel_PLG,kel_PLS,kel_FBG,kel_AP,kel_MG,kel_PAI] = elimination_para();

%% Kinetic parameters
% [kcat_tPA,KM_tPA,kcat_PLS,KM_PLS,kcat_AP,KM_AP,kMG,kPAI] = kinetic_para();
% [k1f,k1r,k2,k3f,k3r,k4,k5f,k5r,k6,kMG,kPAI] = kinetic_para();
%[KM_PLG,k_PLG_cat,k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
%[x(1),x(2),x(3),x(4),x(5),x(6),x(7),x(8),x(9)] = kinetic_para();
%[x(1),x(2),k_AP_f,k_AP_r,k_AP_cat,KM_FBG,k_FBG_cat,kMG,kPAI] = kinetic_para();
KM_PLG=x(1);
k_PLG_cat=x(2);
k_AP_f=x(3);
k_AP_r=x(4);
k_AP_cat=x(5);
KM_FBG=x(6);
k_FBG_cat=x(7);
kMG=x(8);
kPAI=x(9);

%% initial concentrations in plasma
[C_tPA0,C_PLG0,C_PLS0,C_FBG0,C_AP0,C_MG0,C_PAI0] = initConc_values();
%% Treatment specific parameters
% === INPUT ===============================================================
tPAdose = 0.9*80;                     % total tPA dose in [mg]
N_stage = 2;
t_infusion = [1,60]*60;    % infusion duration [s]
t_delay = [0]*60;           % time delay between infusion modes [s]
perc_infusion = [0.1,0.9];    % percentage of each infusion of total amount [-]
% =========================================================================
[tPAdose_array, timePoints, t_ramping] = dosageRegimen_func(tPAdose,N_stage,t_infusion,t_delay,perc_infusion);
%% Calculate infusion rate
dt = 0.01;%0.075;
% tspan = 0:dt:(sum(timePoints)+60*100);       % simulation duration [s]
% tspan = 0:dt:3600+60+30*60;       % simulation duration [s]
tspan = 0:dt:300*60
for ii=1:length(tspan)
    IR_tPA(ii) = infusionRate_func_general(tspan(ii), tPAdose_array, timePoints, t_ramping);
end
% dd
%% Solve ODE for the compartmental model
% --- initial conc. [central tPA, pheripheral tPA, PLG, PLS, FBG, AP, MG, PAI] [micro M] - 9 factors
Cintit = [C_tPA0, 0, C_PLG0, C_PLS0, C_FBG0, C_AP0, C_MG0, C_PAI0, 0];
[tsolve,Csolve] = ode23s(@compartmentalODE_NewFunc,tspan,Cintit,[],tPAdose_array,timePoints,t_ramping);

g=Csolve(180000,1);
end
