function tsolve = compartmentalModel_NewMainNew(epsilon_0, rho_fibre, rho_0)
    % Global variables declaration
    global kel_PLG kel_PLS kel_FBG kel_AP kel_MG kel_PAI k12 k21 k10
    global C_tPA0 C_PLG0 C_PLS0 C_FBG0 C_AP0 C_MG0 C_PAI0
    global KM_PLG k_PLG_cat k_AP_f k_AP_r k_AP_cat KM_FBG k_FBG_cat kMG kPAI

    % Properties Parameters
    [k12, k21, k10, kel_PLG, kel_PLS, kel_FBG, kel_AP, kel_MG, kel_PAI] = elimination_para();
    [KM_PLG, k_PLG_cat, k_AP_f, k_AP_r, k_AP_cat, KM_FBG, k_FBG_cat, kMG, kPAI] = kinetic_para();
    [C_tPA0, C_PLG0, C_PLS0, C_FBG0, C_AP0, C_MG0, C_PAI0] = initConc_values();

    % Modify initial concentrations or kinetic parameters based on the input
    k_PLG_cat = k_PLG_cat * epsilon_0;
    k_FBG_cat = k_FBG_cat * rho_fibre;
    k_AP_cat = k_AP_cat * rho_0;

    % Treatment specific parameters
    tPAdose = 0.9 * 80; % total tPA dose in [mg]
    N_stage = 2;
    t_infusion = [1, 60] * 60; % infusion duration [s]
    t_delay = [0] * 60; % time delay between infusion modes [s]
    perc_infusion = [0.1, 0.9]; % percentage of each infusion of total amount [-]

    [tPAdose_array, timePoints, t_ramping] = dosageRegimen_func(tPAdose, N_stage, t_infusion, t_delay, perc_infusion);

    % Calculate infusion rate
    dt = 0.01;
    tspan = 0:dt:200 * 60;
    IR_tPA = zeros(size(tspan));
    for ii = 1:length(tspan)
        IR_tPA(ii) = infusionRate_func_general(tspan(ii), tPAdose_array, timePoints, t_ramping);
    end

    % Solve the compartmental ODE
    %% Solve ODE for the compartmental model
% --- initial conc. [central tPA, pheripheral tPA, PLG, PLS, FBG, AP, MG, PAI] [micro M] - 9 factors
Cintit = [C_tPA0, 0, C_PLG0, C_PLS0, C_FBG0, C_AP0, C_MG0, C_PAI0, 0];
[tsolve,Csolve] = ode23s(@compartmentalODE_NewFunc,tspan,Cintit,[],tPAdose_array,timePoints,t_ramping);
filename = ['compartSol_low','.csv'];
% dlmwrite(filename,[tsolve,Csolve(:,[1,3:4])],'precision','%4.2f')
% 
% dd
  
%[tsolve, Csolve] = compartmentalODE_NewFunc(tspan, IR_tPA);

    % Calculate lysis time based on some criteria
    % Assuming lysis time is the time when plasminogen concentration reaches a specific threshold
    threshold = 0.5; % Example threshold
    lysis_index = find(Csolve(:, 4) <= threshold, 1, 'first');
    if isempty(lysis_index)
        tsolve = NaN; % If threshold is never reached, return NaN
    else
        tsolve = tsolve(lysis_index) / 60; % Convert to minutes
    end
end